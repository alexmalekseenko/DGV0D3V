function memory_estimator

n=41
mem_lin_coll_GB=(n^6)*8/1024/1024/1024
