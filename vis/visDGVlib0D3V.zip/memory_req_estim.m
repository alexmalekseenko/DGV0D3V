n=1
m=41
SD=1
MemLinColl = 8*(n^(SD))*m^6/2^30